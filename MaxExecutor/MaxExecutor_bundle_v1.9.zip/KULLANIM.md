# MaxExecutor PAKETİ — TAM KULLANIM KILAVUZU (Türkçe)

> Paket içeriği, kurulum, komutlar, giriş akışı, sorun giderme — hepsi bu dosyada.
> Mimari gerekçe için: `reports/DEV_REAL_BINARY_TEST.md` (RC18/RC19) + `reports/DEV_GIL_ANALYSIS.md` (RC1-RC17).
> Son güncelleme: **Oturum 16 — v1.9 PLUSMAXGOD / pylib v4.3 (BALIK-FIX + OTP + klon-mod + tam taramalar)**

> **v1.9/v4.2 ÖZET — saha testi 9 (kullanıcı: "hepsi başarılı, sadece serverlist hatalı") + GOD MOD istek listesi:**
> **Serverlist kök nedeni:** ServerList pencere öğesi `listbox2` → `ui.ListBox2` sınıfı; **GetItemText metodu YOK** (ui.py:3094-3274, isimler `keyDict`/`textDict` sözlüğünde). v4.1 "isim okunamadı" basıyordu; v4.2 sözlüğü doğrudan okur + kendi sonuç dosyası (last_serverlist.txt — selserver üstüne basmıyor).
> **YENİ 28 KOMUT:** `unequip <parça|slot>` `unequipall` `chchange <ch>` `relogin` `ground` `groundtake` `autotake` `quest` `fakeitem` `fakeclear` `clone` `unclone` `spawn <race> [ad]` `morph <race>` `unmorph` `setarmor` `setweapon` `simya|ds` `itemscan` `fish` `fishstop` `fishdelay` `fishkeep` `fishswap` `fishspot` `fishstat` `fishtest` `canli`. Detay: **bölüm 3e**.
> **CANLI ÇIKTI (FIX-36):** pylib `C:\MaxExec\live.txt`'ye durum yazar; DLL her 700ms okur, konsola `[LIVE]` önekiyle AKITIR. Balık/CH değişimi/otomatik toplama durumları canlı izlenir.
>
> **v1.9/v4.3 ÖZET — saha testi 10 dersi (MaxExec_sonuc_x.rar: 32 atış, 0 ısırma, 14 kaçan) + tam kaynak analizi (LegendySF GameSource + ClientSource):**
> **Balığın tutmama kök nedeni (KAYNAKLA KANITLI):** ısırma paketi (GC_REACT) Python'a HİÇ callback göndermiyor — client kaynak `PythonNetworkStreamPhaseGame.cpp` REACT dalında sadece C++ `SetFishEmoticon()+ReactFishing()` var. `OnFishingNotify` SADECE sunucu `PredictFish()` TRUE ise gelir = **balık-zihni hapi (vnum 27610)** aktifken (fishing.cpp:374 `AFFECT_FISH_MIND_PILL`, char_item.cpp:3053). v4.2 döngüsü ısırma görmedi → her kaçış oltaya yemi SIFIRLADI (`fishing_event` default dal: `rod->SetSocket(2,0)`) → sonraki atış yemsiz gitti → 45sn boşa bekledi (log'daki alterne desen bunun kanıtı).
> **v4.3 balık düzeltmeleri:** (1) `fish` başlarken envanterde 27610 varsa OTOMATİK kullanılır — her ısırmda balık adı canlı akar (A+ komutu böyle tam çalışır); hapi yoksa `/i 27610` uyarısı basar. (2) Kaçış/yanlış-yer hook'unda döngü beklemez → hemen yem kontrol + yeniden atış. (3) Yem takılana kadar bekler (soket2>0 → `baitwait`). (4) Baloncuk algısı hem seçili hem ana instance'ta (2-vid). (5) Isırma penceresi 6sn, ısırma 10-40sn (event kaynak kanıtı), timeout 50sn. (6) `fishswap <vnum>` filtresi (`fishswap 11499`) + `fishswapnow` anlık test. (7) `fishtp` = tek atış (ısınla→at→geri ısınla→çek→dur). **400 birim su mesafesi compiled C++ (c_fFishingDistance, GetFishingRot 10° tarama) — Python değişkeni YOK; gerek de yok: sunucu su istemez (char.cpp CHARACTER::fishing → sadece ATTR_BLOCK).**
> **YENİ 10 KOMUT:** `fishtp` `fishswapnow` `otp <x> <y>` `optimizetp` `otpstop` `otpstep <px>` `otpdelay <ms>` `clonemod <swap|1|0>` `spawnscan [min] [max]` `itemscanall`. **OTP (OptimizeTP):** sunucu FUNC_MOVE paketinde mesafe >25m ise `ch->Show(eski konum)` ile GERİ ATAR (input_main.cpp ENABLE_TP_SPEED_CHECK — kullanıcının saha raporuyla birebir). `otp` = 240px (24m) adım + `MoveToDestPosition` + 1300ms bekleme → sunucu senkron takip eder, yürümek serbest. **KLON:** sac kopyalama (probe) + `clonemod swap` (yer değiş-tokuş) / `clonemod 1` (takip/ayna); gerçek "klon kontrolü" sunucu tarafı imkânsız (input hep gerçek karaktere gider). **SPAWN/MORPH:** race istemci mob_proto'sunda yoksa görünmez olur (`nonplayer.GetMonsterName` ile ön kontrol; morph 20016 saha kanıtı) → `spawnscan 1 30000` geçerli race'leri `C:\MaxExec\spawnscan_full.txt`'e döker. **ITEMSCAN:** tam liste artık `C:\MaxExec\itemscan_full.txt` (Python doğrudan yazar — DLL sonuç dosyası limiti yok) + `itemscanall` = 1-99999 tam tarama.
>
> **v4.1 ÖZET — saha testi 8 dersi (kullanıcı: "oyunun kendi kullandıklarını 1kb dumpladı, tam dumplayamamış"):** v4.0 `pydumpall` 144 hedef buldu; diskteki 73 bot dosyasını TAM döktü (pasha37-levelbot.py = 178KB ✓) AMA oyunun kendi 59 modülü (app/chr/player/game/ui/introLogin...) **2 bayt BOŞ** çıktı. Kök neden 3 katman: (1) `app.GetFileList` bu istemcede **SADECE DISK** listeliyor — 73 dosyanın hepsi senin sonradan attığın botlar (oyun onları kullanmıyor; root/epx'te yok — senin gözlemin doğruydu); (2) oyunun kendi modülleri root **PACK** içinde; (3) `app.OpenTextFile` pack dosyalarında handle verip **0 satır** döndürüyor. **v4.1 çözümü — KANITLI OKUMA ZİNCİRİ** (dump edilen ÇALIŞAN botların kendi kodundan çıkarıldı): `pack.Exist`+`pack.Get` (FileExtractor.py "ScriptStealer" + New_Levelbot.py:363 `pack.Get("playersettingmodule.py")` root pack'ten KAYNAK okuyor!) → `pack_open(ad,"r")` (edithack.py:888 + itemcreator.py:418) → `app.OpenTextFile` (artık YEDEK) → disk. `pydumpall` hedefleri artık **canlı sys.modules'ten** (130 modül) + UI script yollarından (locale/ro/ui + UIScript, oyun log kanıtlı) üretilir; INDEX.txt'e **yöntem + byte kolonu** geldi; 0 byte = `BOS` işaretli (sahte OK yok). `pyfiles`'a `[6] pack API keşfi` + `[7] modül __file__` raporu geldi. **Saha testi 8'de ÇALIŞANLAR:** stat/pos/skill/near/tp/goto/attack/chat/revive/pyfiles/pyscan/plusquest (439KB canlı katalog) — hepsi temiz. Komut yazım hatası notu: `player.ClickSkillSlot(15)` tek başına komut DEĞİL → `raw player.ClickSkillSlot(15)` yaz.
>
> **v1.8 ÖZET — oturum 13 (kullanıcı raporu: v1.7 HEPSİ ÇALIŞTI ✓):** Saha doğrulaması sonrası iki yeni yetenek ailesi eklendi. **(A) OYUN-İÇİ KOMUTLAR:** `stat` (seviye/HP/SP/EXP), `pos` (x/y/z + harita), `inv <sayfa>` (envanter), `equip` (ekipman), `skill` (beceriler), `near` (yakın varlıklar), `chat <mesaj>` / `cmd /komut` (sohbet), `whisper`, `ride/revive/logout/back/pickup`, `zoom <mesafe>`, `use <slot>`, `drop <slot> <adet>` (DİKKAT), `goto <x> <y>` (yürü), `tp <x> <y>` (ışınla), `key <DIK> <0/1>`, `attack <0/1>`. Hepsi kanıtlı API'ler — nighttown koleksiyonu 4000+ kullanım + cycu.py. **(B) KESİF KOMUTLARI:** `pyfiles`, `pydump <ad>`, `pydumpall` (HEPSİNİ `C:\MaxExec\dump`'a + INDEX.txt), `pyscan <modul>`, `plusquest` (tüm modülleri tara → PLUSQuest_live.txt). **(C) YENİ ADLANDIRMA:** pylib artık diskte **PLUSMAXGOD_PyScript.py** olarak yaşar (DLL v1.8 otomatik yazar/yükseltir; eski pylib.py hâlâ yedek yol olarak kabul edilir — BootImport yerinde yükseltir). Katalog: **PLUSQuest.md** (MaxExecutor klasöründe).
>
> **v1.7 ÖZET — saha testi 7 dersi (oturum 12):** v1.6'nın 30 komutu da temiz çalıştı (pyfail=0) ve iki gerçek oyun-düzeyi bulgu çıktı. **(1) `enter` oyuna sokmuyor:** `net.DirectEnter` YENİ oluşturulan karakterde sunucu tarafından reddediliyor (loading penceresi açılıp login ekranına geri atıyor); eski karakterlerde (raynare) çalışıyor. Oyunun kendi START butonu ise çalışıyor — kullanıcı doğrulaması + MaximumPyScript_Merged_calisan kanıtı. **v1.7 `enter`: önce SelectSlot + StartGame/startButton (UI yolu); DirectEnter sadece UI yolu bulunamazsa YEDEK.** Çift-giriş yasağı (RC12) korunur: UI yolu seçilince DirectEnter hiç çağrılmaz. **(2) mkchar'dan sahte CREATE_FAILURE:** çift paket gidiyordu — UI OLUSTUR butonu paketi kendisi yolluyor + pylib bir de direkt SendCreateCharacterPacket yolluyordu → 1. paket başarı, 2. paket `CREATE_FAILURE: 0 (0 karakter yaratılamaz)`. Karakter zaten oluşmuştu; sahte hataydı. **v1.7 mkchar: paket yolu SADECE buton bulunamazsa.**
>
> **v1.3 ÖZET — saha testi 26.10 dersi:** kuyruk/drenaj/ana-thread zinciri ÇALIŞIYORDU (kanıt: `results\py_probe.txt` oluştu, `alive.txt` aktti) ama makinede **`C:\MaxExec\pylib.py` dosyası yoktu**. `load` sessiz IOError yedi, `maxlib` hiç kurulmadı; her `status`/`login`/`waitfor` komutu pyerr.log'a "ImportError: No module named maxlib" yazdı (100+ kez). **v1.3 pylib.py'yi otomatik yükler** — dosya yoksa baştan uyarır.

> **v1.5 ÖZET — saha testi 5 dersi (oturum 10):** makinede DLL v1.4 vardı ama `pylib.py` hâlâ **v2.0** idi (eski bundle'dan). Yeni komutlar (selchar/mkchar/delchar...) sessiz `AttributeError` yedi — konsol hiçbir şey söylemedi, hatalar yalnız pyerr.log'daydı. v1.5 bunu kökten bitirir: **pylib v3.0 artık DLL'İN İÇİNE GÖMÜLÜ** — diskteki pylib eksik/eskiyse DLL otomatik yazar (eskisini pylib_eski_vX.py olarak yedekler), sürüm uyumsuzluğu varsa açılışta KOSKOCA uyarı basar, Python hatası olursa konsol artık `!! PYTHON HATASI — detay: pyerr` diye BAĞIRIR (sessiz hata devri kapandı).

> **v1.6 ÖZET — saha testi 6 dersi (oturum 11):** v1.5'in hata görünürlüğü asıl problemi ortaya çıkardı: **neredeyse her komut `PYTHON HATASI` veriyordu.** Kök neden: v1.5, komutların import-bootstrap'ına sürüm-koruması ekleyince metin ~660 karaktere büyüdü; ama eski komut üreticileri hâlâ `char buf[256]/[512]` + `_snprintf` ile kod üretiyordu → kuyruktaki .cmd dosyaları **satır ortasında kopuk Python kodu** içeriyordu (255/511 byte) → `SyntaxError: EOL while scanning string literal` → komut hiç çalışmıyordu. Kanıt zinciri: maxexec.log'ta 674 byte'lık komutlar (newchar/joblist/lasterr — std::string ile üretilenler) ÇALIŞTI; 255/511 byte'lıklar PATLADI; pyerr.log'daki kesik satırlar birebir bu kesime noktasına denk geliyor. **v1.6: tüm üreticiler std::string'e çevrildi (FIX-23) — kesilme yapısal olarak imkânsız.** Bonuslar: Python `print`'leri konsola düşüyor (FIX-28), `charlist`/`joblist`/`mkchar`/`selchar` raporları CANLI görünüyor (pylib v3.1 yankısı), oyun hataları (yanlış şifre vb.) olduğu AN konsola `[OYUN HATASI]` satırı düşüyor, eksik argümanlı komutlar `kullanim:` mesajı veriyor, `status` bayat dosya göstermiyor (FIX-27).

---

## 1. PAKET İÇİNDE NE VAR?

| Dosya | Ne işe yarar | Nereden geldi |
|---|---|---|
| `bin/MaxExecutor.dll` | **Ana proje.** Oyun içine enjekte edilen 32-bit DLL. Ana thread'de (WndProc + SetTimer) Python çalıştırır. Hook YOK, SHM YOK, arka-plan PyRun YOK. **v1.8: PLUSMAXGOD komut ailesi (oyun-ici + kesif) + surum-ongoer BootImport + dump klasoru.** | Bu repo — derlendi (32-bit PE, `-O2`; zig cc `x86-windows-gnu`) |
| `bin/MaxInject.exe` | DLL enjektörü. `metin2client.exe` sürecini bulur, DLL'i LoadLibrary ile yükler. | Bu repo — derlendi |
| `PLUSMAXGOD_PyScript.py` | **pylib v4.1 (maxlib).** DLL içine gömülü; diskte eksik/eskiyse otomatik yazılır. Tüm komutlar: menü (login/charlist/mkchar...) + oyun-ici (stat/inv/tp...) + kesif (pyfiles/pydumpall/plusquest). | Bu repo |
| `pylib.py` | Eski v3.2 adı — YEDEK yolu olarak kabul edilir (BootImport önce PLUSMAXGOD'u dener). Silinebilir; DLL yeniden yazmaz. | Bu repo |
| `MaximumPyScript_STABLE.py` | Eski mimarinin (SHM'li v17) RC12/RC13/RC14 yamalı hali. Alternatif yol. | Bu repo |
| `MaxExecutor.cpp` / `MaxInject.cpp` | Kaynak kodlar (değişiklik yaparsan yeniden derlersin) | Bu repo |
| `README.md` | Mimari açıklama (İngilizce başlıklı ama içerik Türkçe) | Bu repo |

**Derleme ortamı (v1.1):** Debian GCC 14.2 mingw-w64 (win32 threads), i686-w64-mingw32, `-static` (579KB DLL, bağımlılık: yalnız USER32/KERNEL32 + UCRT). **v1.8: zig 0.11.0 (root-less) — 614KB DLL.**

---

## 2. KURULUM (5 ADIM, ~2 DAKİKA)

1. **Klasörü hazırla** — oyunun kurulu olduğu bilgisayarda:
   ```
   C:\MaxExec\
       MaxExecutor.dll
       MaxInject.exe
   ```
   (pylib.py artık ZORUNLU DEĞİL — v1.5 DLL'in içinde gömülü; diskte eski/eksikse otomatik yazar. Yine de yanına koymak istersen bundle'daki pylib.py'yi kopyala.)
2. **Oyunu aç** → login ekranı görünene kadar bekle (pencere oluşsun).
3. **Enjekte et** — Komut İstemi'ni (cmd) **Yönetici olarak** aç:
   ```
   cd C:\MaxExec
   MaxInject.exe
   ```
   - Otomatik: `metin2client.exe` sürecini arar.
   - Başka isimli client: `MaxInject.exe metin2.exe`
   - PID ile: `MaxInject.exe 12345`
   - Farklı DLL yolu: `MaxInject.exe metin2client.exe D:\yer\MaxExecutor.dll`
4. **Konsol açılır** — "MaxExecutor v1.8 PLUSMAXGOD" başlıklı siyah pencere (oyunun ÜSTÜNDE kalır, TOPMOST).
   İlk satırlarda şunları görmelisin:
   ```
   python27.dll : BULUNDU [initialized]
   PLUSMAXGOD_PyScript.py : v4.1 (uyumlu) - otomatik yuklenecek
   oyun penceresi: SUBCLASS EDILDI (hwnd=0x...)
   ana-thread timer: KURULDU
   ```
   > `PLUSMAXGOD_PyScript.py : GUNCELLENDI -> v4.1 (DLL icinden yazildi)` görürsen: diskteki pylib eskiymiş (veya v3.2 idi), v1.8 gömülü kopyayı yazdı — ekstra bir şey yapmana gerek yok. Eski dosya `PLUSMAXGOD_eski_*.py` olarak yedeklenir.
   > Eski `pylib.py` v3.2 yerinde duruyorsa bile sorun yok: BootImport sürümü okur, v4'ten küçükse PLUSMAXGOD_PyScript.py ile YERİNDE yükseltir (FIX-32).
   > `!! PYLIB ESI` uyarısı görürsen: pylib yazılamadı demektir (yazma hatası) — o zaman elle kopyala.
   > `python27.dll : YOK` ise oyunun Python'u henüz başlamamıştır → konsolda bekle,
   > oyun login ekranına gelince `status` yazarak tekrar dene (DLL her 0.5 sn'de yeniden dener, 20 sn boyunca).
   > Konsol bir sebeple hiç açılmazsa: `C:\MaxExec\maxexec.log` dosyasına bak (her adım oraya yazılır)
   > ve §6'daki "headless mod" başlığına geç.
5. **Hazır.** §3'teki akışa geç.

> ⚠️ **Win7/Win8'de "api-ms-win-crt-*.dll eksik" hatası alırsan:** Visual C++ 2015-2022 Redistributable (x86) kur → UCRT'yi getirir. Win10/11'de gerekmez.

---

## 3. İLK GİRİŞ AKIŞI (komut sırası birebir)

> ⚠️ **Bu client'ta login'den ÖNCE server listesi ekranı var** (server isimleri + CH listbox + OK butonu).
> O yüzden akış `selserver` ile başlar.

MaxExecutor konsolunda sırayla:

```
status                                  (0) SCENE= ne diyor bak (LoginWindow+ServerList ise dogru ekrandasin)
                                        (1) load ARTIK YOK — v1.3 pylib.py'yi otomatik yükler
                                           (kanıt: results\last_pylib_load.txt, 2 sn içinde oluşur)
selserver 0 0                           (2) listedeki 0. sunucu + 0. CH'yi seç, OK'a bas
serverlist                              (*)  isimleri/listbox içeriğini görmek istersen
waitfor LoginWindow 15                  (3) login (id/şifre) ekranına düşünceye kadar
login kullaniciadim sifrem              (4) id+şifre doldur + giriş
waitfor SelectCharacterWindow 30        (5) karakter seçme ekranı
charlist                                (6) 5 slot tablosu
enter 0                                 (7) 1. slotla oyuna gir (UI START yolu)
waitfor GameWindow 60                   (8) oyun + NPC spawn
status                                  (9) son durum
pyerr                                   (*)  Python hatası olduysa son 30 satırı konsola döker
```

Sonuç dosyaları `C:\MaxExec\results\` altında: `py_probe.txt` (zincir kanıtı), `last_status.txt`, `last_server.txt`, `last_login.txt`, `last_charlist.txt`, `last_enter.txt`, `last_error.txt`, `last_pylib_load.txt`.

### SAHA DOĞRULAMALI SENARYOLAR (v1.7, oturum 12 testi: HEPSİ ÇALIŞTI ✓)

> Bu iki akış gerçek sunucuda uçtan uca test edildi (giriş → bayrak → oluşturma → oyuna giriş → silme).
> `waitfor` sahne adını `SCENE=` çıktısıyla eşleştirir (substring). Bu sunucuda bayrak ekranının
> sahne adı **ReselectEmpireWindow**'dur (SelectEmpireWindow.py yüklenir ama sahne adı böyle raporlanır).

**SENARYO A — BAYRAK SEÇMELİ** (hesapta 0 karakter / ilk karakter; testte tam olarak bu akış çalıştı):
```
status
selserver 0 0
waitfor LoginWindow 15
login <id> <sifre>
waitfor SelectCharacterWindow 30
charlist
newchar                        bayrak ekranı açılır (ilk karakter)
waitfor ReselectEmpireWindow 10
empirelist                     mevcut empire + bayrak tablosu
empireui 2                     1=Shinsoo 2=Chunjo 3=Jinno -> OLUSTURMA ekranı açılır
waitfor CreateCharacterWindow 10
joblist                        sinif/cinsiyet tablosu + ekran durumu
mkchar Isim 5                  sinif gez + cinsiyet + isim + OLUSTUR (tek paket)
waitfor SelectCharacterWindow 15
charlist                       yeni karakter slotta mi?
selchar 0
enter 0                        UI START yolu (StartGame) -> oyun yüklenir
waitfor GameWindow 60
status
```

**SENARYO B — BAYRAK SEÇMESİZ** (empire kayıtlı; `newchar` direkt olusturma ekranını açar):
```
status
selserver 0 0
waitfor LoginWindow 15
login <id> <sifre>
waitfor SelectCharacterWindow 30
charlist
newchar                        bayrak atlanir, direkt CreateCharacterWindow
waitfor CreateCharacterWindow 10
joblist
mkchar YeniIsim 5
waitfor SelectCharacterWindow 15
charlist
selchar 0
enter 0
waitfor GameWindow 60
status
```

**SİLME AKIŞI** (test edildi: delchar → delcode → 0 karakter → sonraki newchar bayrak ekranını açtı):
```
charlist
delchar <slot>                 silme sorusu + kod dialogu ACAR
delcode <kod>                  kodu yazar + ONAYLAR
waitfor SelectCharacterWindow 10
charlist                       slot BOS mu?
lasterr                        DELETE_SUCCESS/DELETE_FAILURE kaydi
```
> Not: `chardel` diye bir komut YOK — doğrusu `delchar` (saha testinde 3 kez karıştırıldı).

### ZİNCİR KOPTU MU? (bir şey olmuyorsa 30 sn bekle, sonra bak)

| Kontrol | Ne demek |
|---|---|
| `results\py_probe.txt` VAR | Ana thread Python'u çalışıyor — zincir TAMAM. Sorun Python/pylib tarafında → `pyerr.log` |
| `results\py_probe.txt` YOK + `alive.txt`'de `exec=0` | Komutlar kuyruğa giriyor ama çalıştırılmıyor |
| `alive.txt`'de `timer>0` artıyor | Oyun mesaj pompası TimerProc'u çağırıyor — drenaj yaşıyor (v1.2 ana yol) |
| `alive.txt`'de `msg>0` artıyor | WndProc subclass da yaşıyor |
| `alive.txt` HİÇ yok / 2 sn'de bir güncellenmiyor | Drain hiç çağrılmıyor — `maxexec.log`'a bak (SetTimer satırı var mı?) |
| `alive.txt` içeriği örnek: `tick=110017796 drain=412 exec=8 timer=409 msg=3 py=1` | `drain` akıyor ama `exec` 0 ise python27 çözülememiş → `maxexec.log` |


---

## 3b. KARAKTER İŞLEMLERİ (v1.4 — giriş yaptıktan sonra)

> pylib v3.0 **otomatik hata izleme** kurar: `LoginWindow.OnLoginFailure` +
> `SelectCharacterWindow.OnCreateFailure/OnDeleteFailure/OnDeleteSuccess` hook'ları
> (Python-seviye, kanıtlanmış desen). Yanlış şifre, isim çakışması, silme sonucu →
> `results\last_error.txt`'ye düşer. Konsolda görmek için: **`lasterr`**

### a) Slot seçme / girme
```
charlist              tabloya bak (hangi slotlar dolu/bos)
selchar 4             4. slotu SEÇ (isaretler; girmez)
enter 2               2. slotla OYUNA GİR (UI START yolu - StartGame butonu)
```

### b) Yeni karakter oluşturma (2 ekran: bayrak → sınıf/cinsiyet/isim)
```
newchar               "karakter olustur" butonuna basar
status                hangi ekran geldigine bak
  SCENE=SelectEmpireWindow   -> bayrak ekrani (ilk karakter)
  SCENE=CreateCharacterWindow -> direkt olusturma (bayrak kayitliysa)

bayrak ekrani geldiyse:
empirelist            bayrak listesi + mevcut empire (1=Shinsoo 2=Chunjo 3=Jinno)
empireui 1            bayrak sec + ILERLE butonu (paket yolu yedekli)
waitfor CreateCharacterWindow 10

olusturma ekraninda:
joblist               sinif/cinsiyet tablosu (race 0-8) + ekran durumu
mkchar YeniIsim 3     sinif gez + cinsiyet + isim + OLUSTUR'a bas
                      (v3.2: paket yolu SADECE buton bulunamazsa - cift paket
                       sahte CREATE_FAILURE: 0 uretiyordu, artik yok)
                      race=3 -> Shaman(K); race=7 -> Shaman(E); 0=Warrior(E)...
waitfor SelectCharacterWindow 15
charlist              yeni karakter slotta mi? (30 sn create cooldown olabilir)
lasterr               hata varsa (isim mevcut = CREATE_FAILURE: 1)
```

### c) Karakter silme (2 adım: soru+kod dialogu → kodu gir)
```
charlist              once bak
delchar 3             3. slotu sec + "karakteri sil" sorusu + kod dialogunu ACAR
delcode 1111111       silme kodunu yazar + ONAYLAR
lasterr               sonuc: DELETE_SUCCESS / DELETE_FAILURE
charlist              slot bosaldi mi?
```
> Bazı serverlar silme kodu istemez (`NOT_NEED_DELETE_CODE`) — delchar çıktısında belirtilir.

### d) Hata komutları özeti
| Komut | Ne gösterir | Kaynak dosya |
|---|---|---|
| `lasterr` | **OYUN hataları** (yanlış şifre=LOGIN_FAILURE: WRONGPWD, isim mevcut, silme sonucu...) | `results\last_error.txt` |
| `pyerr` | **PYTHON hataları** (traceback — kod hatası) | `pyerr.log` |
| `log` | **DLL izi** (EXEC satırları, sayaçlar) | `maxexec.log` |

### create ile yeni karakter (karakter yoksa)
```
charlist                                önce bak: hangi slotlar boş?
empire 1                                gerekliyse bayrak/imparatorluk seç (1=Shinsoo 2=Chunjo 3=Jinno)
create 0 MaxAdi 2 0                     slot0, isim, race=2 (Sura-E), shape=0
enter 0
```
**race tablosu (LegendySF MAIN_RACE):** 0=Savaşçı-E, 1=Ninja-K, 2=Sura-E, 3=Şaman-K, 4=Savaşçı-K, 5=Ninja-E, 6=Sura-K, 7=Şaman-E, 8=Wolfman-E.
**Hata takibi:** `results/last_error.txt` — `isim mevcut (bType=1)` / `karakter yaratılamaz (bType=0)` / 30 sn create cooldown bilgisi buraya düşer.

### serbest komut
```
raw import net; net.SendChatPacket("merhaba", 0)
raw print(net.GetMainActorVID())     → çıktı C:\MaxExec\results\last_error.txt değil; stdout oyun loguna gider.
```
> Not: `raw` ile `print` çıktısı MaxExec konsoluna DEĞİL, oyunun kendi debug çıkışına gider.
> Değer almak için maxlib desenini kullan (dosyaya yazar).

---

## 3c. OYUN-İÇİ KOMUTLAR (v1.8 PLUSMAXGOD — `waitfor GameWindow 60` SONRASI)

> Tümü oyunun KENDİ kanıtlı API'lerini kullanır (nighttown koleksiyonu 4000+ kullanım +
> cycu.py — kullanıcının ekosistemi). Her komut önce "oyunda mıyız?" kontrolü yapar;
> menü ekranındaysa `HATA: oyunda degilsin (once waitfor GameWindow 60)` der.
> Raporlar `results\last_<komut>.txt`'e yazılır + konsola canlı basılır.

### a) Durum raporları
```
stat       ad/seviye/HP%/SP%/EXP%/race/skill grubu/empire/hız/biniş durumu
pos        vid + x/y/z + metre (x/100) + HARİTA ADI (background.GetCurrentMapName)
           + hazır tp/goto önerisi
inv 0      envanter 1. sayfa (45 slot): slot/vnum/isim/adet — INVENTORY_PAGE_SIZE'dan okunur
inv 1      2. sayfa (45..89)
equip      ekipman slotları (EQUIPMENT_BASE_INDEX=90+: silah/zırh/kolye...)
skill      beceriler: slot/idx/isim/Lv/Grade/CD (GetSkillIndex yoksa öğretilmiş tarama)
near       10000 birim yarıçaptaki varlıklar: vid/tip/dist/isim/Lv (VID sweep 1..2000,
           chr.GetInstanceType + GetNameByVID + nonplayer.GetLevelByVID — kanıtlı)
```

### b) Sohbet + eylemler
```
chat merhaba            genel sohbet paketi (net.SendChatPacket)
cmd /ride               slash komut (aynı yol — /ride /logout /phase_select ...)
whisper Oyuncu selam    özel mesaj (net.SendWhisperPacket)
ride | revive | logout | back | pickup   hızlı eylemler (cycu.py kanıtları)
zoom 12000              kamera menzili (app.SetCameraMaxDistance)
use 5                   5. slottaki eşyayı KULLAN (net.SendItemUsePacket — 218 kanıt)
drop 5 1                5. slottan 1 adet YERE BIRAK — DESTRUKTİF, geri alınamaz!
```

### c) Hareket
```
pos                     önce konumu oku (x/y + harita)
goto 95900 269000        KONUMA YÜRÜ (chr.MoveToDestPosition(vid,x,y) — yol izler)
tp 95900 269000          KONUMA IŞINLAN (chr.SetPixelPosition(x,y) — 211 kanıt;
                         server koordinat doğrulaması yoksa anlık ışınlanma)
key UP 1 / key UP 0      tuş simülasyonu (player.SetSingleDIKKeyState — 368 kanıt!)
attack 1 / attack 0      saldırı basılı tut / bırak (player.SetAttackKeyState — 100 kanıt)
```
> `goto` yürümedir (animasyonlu, mesafe kademeli), `tp` anlıktır. Bazı sunucular tp'yi
> sunucu tarafında doğrular — ışınlanma sonrası `pos` ile doğrula, geri atarsan `goto` kullan.

### d) Kesif akışı (oyunun python dosyalarını çek + incele) — v4.1
```
pyfiles                 6 rapor: app.GetFileList (SADECE DISK - saha testi 8) +
                        sys.modules (canli 130 modul) + pkgutil (yok - beklenen) +
                        disk taramasi + import-probe + [6] pack API kesfi (dir(pack),
                        Exist/Get/pack_open var mi) + [7] modul __file__ raporu
pydump introLogin       TEK dosyayi KANITLI ZINCIRLE oku → C:\MaxExec\dump\ + ilk 40 satir
                        (zincir: pack.Get → pack_open → app.OpenTextFile → disk;
                        buyuk-kucuk harf varyantlari otomatik denenir)
pydumpall               HEPSINI dok → C:\MaxExec\dump\*.py + INDEX.txt
                        hedefler: sys.modules canlisi (oyunun KENDI modulleri!) +
                        probe + disk + UI script yollari (locale/ro/ui + UIScript);
                        INDEX'te yontem + byte kolonu; 0 byte = BOS isaretli
pyscan player           yüklü modülün fonksiyonları + argüman adları (py2 func_code)
plusquest               TÜM yüklü modülleri tara → C:\MaxExec\dump\PLUSQuest_live.txt
                        (oyundayken çalıştır — daha fazla modül yüklü olur)
```
> **SONRAKI ADIM:** `C:\MaxExec\dump` klasörünü ZIP'le → AI'ya gönder → PLUSQuest.md kataloğu
> senin istemcinin gerçek dosyalarıyla zenginleştirilir.
>
> **SAHA TESTİ 8 HÜKMÜ (v4.1'in nedeni):** v4.0 `pydumpall` 144 hedef buldu; diskteki 73
> bot dosyasını TAM döktü AMA oyunun kendi 59 modülü (app/chr/player/game/ui...) **2 bayt
> boş** çıktı. Nedenler: (1) `app.GetFileList` bu istemcede SADECE DISK listeliyor — 73
> dosyanın hepsi senin sonradan attığın botlar (oyun onları kullanmıyor, root/epx'te yok);
> (2) oyunun kendi modülleri root **PACK** içinde; (3) `app.OpenTextFile` pack dosyalarında
> handle verip **0 satır** döndürüyor. **GERÇEK pack okuma yolu** (çalışan botların kendi
> kodundan çıkarıldı): `pack.Exist(ad)` + `pack.Get(ad)` (FileExtractor.py + New_Levelbot.py:363
> `pack.Get("playersettingmodule.py")` = root pack'ten kaynak okuyor!) ve `pack_open(ad,"r")`
> (edithack.py:888 + itemcreator.py:418, pack içindeki item_list.txt'yi okuyor). v4.1
> `pydump`/`pydumpall` tam bu zincirle çalışır.

### e) GOD MOD v2 komutları (v4.2 — saha testi 9 istekleri) + BALIK REHBERİ

#### Ekipman
```
equip                   rapor: [90..109] slotlar (kanıt: 90=zırh, 94=silah, 97=unique, 99=ok)
unequip body            ÇIKAR (parça: body/head/shoes/wrist/weapon/neck/ear/unique/arrow/costume
                        | doğrudan slot: 90-109) — takılı slota use paketi = çıkarma (kullanıcı doğruladı)
unequipall              hepsini çıkar (envanterde yer lazım)
use <slot>              TAK (kullanıcı saha testi 9'da doğruladı ✓)
```

#### Kanal değiştirme (oyundan çıkmadan) — farmbot yolu
```
login deneme2 1         (bir kez; kimlik C:\MaxExec\login.dat'a kaydolur)
chchange 2              otomatik akış: bağlantıyı kes → login ekranı → server+CH seç →
                        giris → karakter → oyun. 8-20 sn, oyun süreci AÇIK kalır.
relogin                 aynı CH ile otomatik yeniden giriş
```
> Gerçek protokolde CH = TCP bağlantısı; bağlantı değiştirmeden CH değişmez. Bu komut
> süreci kapatmadan TÜM akışı otomatik oynatır (farmbotların klasik yolu). İlerleme [LIVE] ile akar.

#### Yerdeki eşyalar + görevler
```
ground                  yerdeki eşyaları tara → vid + dünya konumu + mesafe
                        (KANIT: textTail.Pick(x,y) ekran taraması — senin pickupstealer.py + Itemstealer.py)
groundtake all | groundtake <vid>    al
autotake 1              sürekli otomatik toplama (0.4sn'de bir tarama; durdur: autotake 0)
quest                   aktif görev raporu — ad + sayaç + kalan süre + idx
                        (KANIT: uicharacter.py:812-876 quest.GetQuestCount/GetQuestData/GetQuestLastTime)
```

#### Hayalet eşya (FAKE ITEM)
```
fakeitem 119            slot 0'dan başlayarak boş slota hayalet yazar (itemcreator.py CreateItem kanıtı:
                        player.SetItemData(slot, vnum, adet); bonus: raw player.SetItemAttribute(slot,0,tip,deger);
                        metin: raw player.SetItemMetinSocket(slot,0,vnum))
fakeclear all           temizle (relogin de temizler)
```
> **DÜRÜST HÜKÜM:** hayalet eşya İSTEMCİ GÖSTERGESİDİR — sunucuda yok; kullan/sat olmaz, takas atamaz,
> diğerleri görmez. Görsel/test amaçlı.

#### Sahte instance / klon / kılık (FAKE INSTANCE)
```
clone                   kendimin klonunu yanına spawn (aynı ırk+zırh+silah; introselect.py MakeCharacter kanıt sırası)
spawn 20016 Demirci     sahte NPC spawn (demirci=20016, genel satıcı=20010, simyacı=20001; race öğrenme: near kolonu race=)
unclone all             sahteleri sil (unclone <vid> tek)
morph 20016             KENDİNİ demirci görüntüsüne dönüştür (ninja yerine); SelectInstance(ben)+SetRace
                        (CInstanceBase::SetRace aktörü yeniden kurar — InstanceBase.cpp:996)
unmorph                 geri (eski ırk kayıtlı)
setarmor 12019          görünüm zırhı (EQChanger.py kanıtı, tek-arg)
setweapon 189           görünüm silahı
```
> **DÜRÜST HÜKÜM:** bunların HEPSİ istemci tarafıdır — sunucu ve DİĞER oyuncular seni gerçek
> karakterin olarak görür; warp/relogin sahte instance'ları temizler, morph'u geri alır.

#### Simya (Dragon Soul) + eşya oluşturma kodu
```
simya | ds              DS (simya) envanteri + ana envanterdeki DS-tipi eşyalar → HER EŞYA İÇİN /i KODU YAZAR
itemscan 55000 55999    eşya tablosu tarama (vnum keşfi; tip kolonlu; ITEM_TYPE_DS/FISH işaretli)
/i <vnum> <adet>        sunucu komutu — saha testi 9 kanıtı: /i 27400 olta, /i 27801 200 solucan
```
> "Simya oluşturma kodu internetten olmuyor" = bu sunucunun `/i` komutu çalışıyor; sorun vnum bilmekti.
> `simya` senin sahip olduklarını listeler (her satırda `/i <vnum> <adet>` hazır), `itemscan` ile
> sunucudaki tabloda var olan tüm vnum'ları keşfedersin.

#### BALIK REHBERİ (A / A+ / AX / AX+ / XX / XY sorularının cevabı)

**TAM MEKANİK** (LegendySF-V2 `fishing.cpp` — klasik mainline; NightTown aynı aile):
1. Atış → sunucu **10-40 sn rastgele** bekler → `GC_REACT` (ısırtma; başta baloncuk = `chrmgr.IsPossibleEmoticon(-1)==0`)
2. Isırtmada **6 saniye pencere**; tepki ms'si ölçülür: `kova = (ms+99)/200` (200ms kova)
3. Başarı zarı: `number(1,100) <= aFishingTime[tip][kova]` — **ANINDA TEPKI HER BALIKTA EN İYİ DEĞİL!**
   Resmî tablo (kova index'ine göre %): tip0: kova 0-4 = **%0**, kova 13-15 = %30-80 · tip1: 3.2-6sn arası (%80, 5sn) ·
   tip2: anında (%80) · tip3: **her zaman %100** · tip4: 3sn (%70-100)
4. Sonra zorluk zarı: `number(1, zorluk) <= olta-seviyesi (soket2+value0)`
5. **KAÇIRIRSAN olta-skilli SIFIRLANIR** (`rod->SetSocket(2,0)`) — 6 sn'den yavaş çıkma!
6. Fish Mind (benekli/71072) → daha iyi balık tablosu (prob_idx 2)

**SORULARIN CEVABI:**
- **A) Deniz kenarı olmadan tutma:** Client atış için 400 birim içinde SU İSTER (`GetFishingRot`, 10'ar derece tarama)
  AMA sunucu su kontrolü YAPMAZ (sadece `ATTR_BLOCK` bakar!). Çözüm `fishspot`: su kenarına `goto` → `fishspot <x> <y>` →
  `fish` → her atış anında su kenarına ışınla-at-geri-dön → **haritanın HER YERİNDE balık tutarsın**. Hiç su olmayan
  haritada (dungeon) ilk atış zaten yapılamaz — istemci paketi hiç göndermez (Python'a balık paketi fonksiyonu da kapalı).
- **A+) Canlı oran ekranı:** VAR. `fish` başlat → cmd penceresinde `[LIVE]` satırları AKITIR: durum, atış/ısırtma/
  tutulan/kaçan, oran %, olta-skill, envanter balığı, ısırtan balığın ADI (sunucu önceden bildirirse OnFishingNotify hook).
- **AX) Her attığını tutma / balık dışı eşya:** Oltayla tutulan balık **sunucuda zarla** belirlenir (`DetermineFish`:
  harita prob tablosu). İstemci balığı SEÇEMEZ; oyuncu/mob tutmak bu kod tabanında imkânsız (paket bile yok).
  Pratik çözüm: `fishkeep <vnum>` — istemediğin balığı otomatik YERE BIRAKIR, hedefe odaklanır.
- **AX+) RNG ile %100'e yönelik:** `fishdelay auto` (varsayılan) **ADAPTİF ÖĞRENİCİ**: balık adına göre
  gecikme→başarı tablosu tutar (fish_learn.txt kalıcı), en iyi gecikmeye yakınsar. + anında çekiş (kova 0-1) tip2/3'te
  zaten %80-100. Zorluk zarı istemci dışı; olta seviyesi yükseldikçe % artar (olta-skill [LIVE] içinde görünür).
- **XX) İstediğin vnum'u oltayla tutmak:** sunucu tarafı zar — istemciden imkânsız (yukarıda). `fishkeep` filtresi en yakın çözüm.
- **XY) Zırh değiştirerek hızlı/%100 tutma:** `fishswap 1` — her sonuçtan sonra envanterdeki başka zırhı giyer →
  tutma/kaçırma animasyonu atlanır, yeniden atış hızlanır (bilinen m2 tekniğinin uygulanmış hâli). %100 vermez,
  döngü hızını artırır.

**HIZLI BAŞLANGIÇ:**
```
fishtest                olta/yem/baloncuk/zırh-adayları raporu (hazır mıyım?)
/i 27400                olta (sunucu komutu — cmd ile)
/i 27801 200            solucan
use <olta-slotu>        tak (inv raporundan slot)
fish                    BAŞLAT → [LIVE] izle
fishstop                durdur
```
> Yem otomatik takılır (27800/27801/27802), ısırtmada otomatik çekilir. `fishdelay 2500` gibi sabit
> gecikmeler tip0 balıklar için gerekir; `auto` öğrenir. `fishstat` öğrenilen tabloyu gösterir.

---

## 4. NEDEN BU MİMARİ GÜVENLİ? (kısa hatırlatma)

| Eski yöntem (cppcmpr / Generated v9.2.0) | MaxExecutor |
|---|---|
| Worker thread'den Python C-API → **GIL crash** (RC1/RC3) | Yalnız ana thread (WndProc) → GIL zaten bizde |
| C++ stack'inde sahte PyInt/TupleObject (RC19) | Sahte obje YOK — gerçek PyRun_SimpleString |
| SendAttackPacket'a prolog hook → MazeProtector/decrypt çakışması (RC18) | Fonksiyon hook'u YOK |
| SHM bayt dilimi komutlar | Atomik dosya kuyruğu (`.tmp` → `MoveFile`) |
| `gc.get_objects()` heap taraması (RC2) | Yok |
| Çift giriş StartGame+DirectEnter → NPC yok (RC12) | Tek giriş: UI yolu seçilince DirectEnter ÇAĞRILMAZ (v3.2); DirectEnter yalnız UI bulunamazsa tek başına |

Worker thread yalnız **dosya yazar + PostMessage** atar; Python'a hiç dokunmaz. Drain her mesajda
en fazla **4 komut** işler ve render'a nefes verir (`MAX_CMDS_PER_DRAIN`).

---

## 5. ESKİ YOL — MaximumPyScript_STABLE.py (alternatif)

Bu, eski SHM mimarisinin yamalı hali (v18-STABLE). **MaxExecutor'u tercih et;** bunu yalnız
eski Controller (win32apiMetin2Py / cppcmpr) zincirini kullanacaksan çalıştır:

1. Eski DLL'in (Kaynak.cpp v6 GILGuard'lı derlemesi) yüklü ve `Control_<PID>` SHM'si açık olmalı.
2. Oyun içi Python'a gir:
   ```
   py exec(open('C:/MaximumPyScript_STABLE.py').read())
   ```
3. Yamalar otomatik uygulanır: tek giriş (NPC fix), loading-recovery kilidi, GameWindow kanıtı.
4. SHM komutları eski MaximumController v4 GUI'siyle aynı.

---

## 6. SORUN GİDERME

| Belirti | Sebep | Çözüm |
|---|---|---|
| **HER KOMUTA `!! PYTHON HATASI`** (v1.5 saha bulgusu 6) | v1.5 hatası: bootstrap ~660 karaktere büyüdü ama eski üreticiler `char buf[256/512]` + `_snprintf` kullanıyordu → .cmd dosyaları satır ortasında kopuk Python kodu (255/511 byte) → SyntaxError. Kanıt: maxexec.log'taki byte boyutları + pyerr.log'daki kesik satırlar | **v1.6 kullan** — tüm üreticiler std::string (FIX-23). Ayrıca pyerr.log'da `EOL while scanning string literal` görüyorsan ve maxexec.log'ta EXEC satırı 255/511 byte diyorsa → kesinlikle v1.5'tesin, v1.6 DLL'i kopyala |
| **newchar/joblist çalışıyor ama selchar/mkchar/delchar HATASI** (v1.5 saha bulgusu) | Aynı kök neden: çalışanlar std::string üreticili, patlayanlar sabit tamponluydu | v1.6 (FIX-23) — yukarıdaki satır |
| **`AttributeError: 'module' object has no attribute 'selchar'`** (ya da herhangi bir yeni komut sessiz kalıyor) | **Diskteki pylib.py eski (v2.0) — DLL yeni** (saha testi 5: DLL v1.4 + pylib v2.0). Yeni komutlar pylib v3.0 ister | **v1.5 kullan: gömülü pylib otomatik yazar** (pylib_eski_*.py yedeği alınır). v1.4'te isen: bundle'daki yeni pylib.py'yi elle kopyala. v1.5'te bu durum ASLA sessiz kalamaz: açılışta `!! PYLIB ESI` uyarısı + komut hatasında `!! PYTHON HATASI — detay: pyerr` konsol satırı + `results\last_warning.txt` / `last_pyfail.txt` |
| **`ImportError: No module named maxlib`** (pyerr.log'da tekrar tekrar; status → "sonuc dosyasi yok") | **`C:\MaxExec\pylib.py` makinede yok** — v1.2 saha bulgusu: `load` sessiz IOError yedi, maxlib kurulmadı, her komut import hatası yedi. Zincir kendisi sağlamdı (py_probe.txt oluştu) | bundle zip'teki `pylib.py`'yi `C:\MaxExec` içine kopyala. **v1.3 otomatik yükler + dosya yoksa konsolda "pylib.py : YOK!!" der; komutlar kendini onarır** |
| **`load` komutu "dosya YOK" diyor** | Yanlış/eksik yol | `load C:/MaxExec/pylib.py` — ya da hiç yazma; v1.3 otomatik yükler |
| **C:\ yazma izni şüphesi** | — | **KANIT: py_probe.txt + alive.txt oyun süreci tarafından yazıldı ve göründü → C:\ sağlıklı, VirtualStore sorunu YOK.** Yine de istersen: `basedir.txt` içine `D:\MaxExec` yaz → tüm dosyalar oraya taşınır (pylib.py'yi de oraya koy!) |
| Python hatasını konsolda görmek | — | **`pyerr`** komutu — pyerr.log'un son 30 satırını döker. **v1.5: hata anında konsol da `!! PYTHON HATASI (dosya) — detay: pyerr` diye uyarır** + `results\last_pyfail.txt` + alive.txt'de `pyfail=` sayacı |
| **Komutlar kuyruğa yazılıyor ama hiçbir sonuç dosyası oluşmuyor** (v1.1 saha bulgusu) | v1.1 drenajı yalnız WndProc subclass + PostMessage'a dayanıyordu; subclass etkisizse zincir ölür | **v1.2+ kullan** — SetTimer yolu WndProc'tan bağımsız. Test: `results\py_probe.txt` oluşmalı (30 sn bekle) |
| `SCENE=?` dönüyor | mainStream frame-walk ile bulunamadı | `status` tekrar dene (frame yürüyüşü her çağrıda çalışır); oyunun intro ekranı değişmişse `raw` ile `import sys; print(sys.modules.keys())` incele |
| `selserver` "serverList.SelectItem YOK" | Bu ekranda değil ya da attr adı farklı | Önce `serverlist` yaz — aday attr'ları raporlar |
| **Konsol açılıyor AMA hiç yazı yazmıyor** (v1.0 hatası) | GUI process'in CRT stdout'u geçersiz handle ile başlar; `AllocConsole` sonrası CRT konsola yeniden bağlanmamıştı | **v1.2'ye güncelle** (freopen CONIN$/CONOUT$ + unbuffered fix). Her adım ayrıca `maxexec.log`'a yazılır |
| `VirtualAllocEx basarisiz: 8` (NOT_ENOUGH_MEMORY) | Oyun 32-bit adres alanı (2GB) pack dosyalarıyla dolu/parçalı | Oyunu ilk açtığın anda (login ekranı çıkınca hemen) inject et; cmd'yi Yönetici yap; olmazsa oyunu yeniden başlat |
| Konsol penceresi görünmüyor | Oyun tam ekran, konsol arkada | v1.1+ konsolu TOPMOST yapar. Alt+Tab ile "MaxExecutor" penceresini ara |
| **Konsol hiç açılmadı (headless mod)** | AllocConsole bazı koruma/ortamlarda başarısız olur | Sorun değil: `C:\MaxExec\queue\` klasörüne komutu elle `.cmd` dosyası olarak bırak — otomatik drenaj işler |
| Python kodum hata verdi, nerede göreceğim? | Python traceback'leri oyun içine gider | `load` sonrası tüm Python hataları `C:\MaxExec\pyerr.log`'da |
| `MaxInject.exe` "sureci bulunamadi" | Oyun kapalı ya da exe adı farklı | Oyunu aç; `MaxInject.exe <gercek-exe-adı>` |
| "OpenProcess basarisiz (5)" | Yönetici değil | cmd'yi Yönetici olarak aç |
| `python27.dll : YOK` | Oyun Python'u başlatmamış | Login ekranına kadar bekle; DLL 20 sn boyunca otomatik tekrar dener |
| `oyun penceresi: BULUNAMADI` | Pencere henüz yok | DLL 20 sn yeniden dener |
| `status` → "sonuc dosyasi yok" | pylib yüklü değil ya da hata yedi | `pyerr` komutuna bak; pylib.py dosyası yerinde mi? (v1.3 otomatik yükler) |
| `login` sonrası hiçbir şey olmuyor | Hatalı ID/şifre veya serverlist ekranı atlanmış | Önce `selserver` yap; sonra `last_login.txt` + `pyerr.log` + oyun popup'ı (OnLoginFailure: NOID/WRONGPWD/ALREADY...) |
| NPC'ler gelmiyor | Eski script alışkanlığı: çift giriş | `enter` TEK SEFER; `waitfor GameWindow 60` ile bekle |
| Oyunda lag/kasma | Çok sık komut | Drain 4 komut/mesaj sınırlı; `raw` spamı yapma |
| GIL hatası hâlâ geliyor | Başka eski DLL enjekte (Kaynak.cpp v1/v2/pythonSenderv1) | O DLL'leri KALDIRIR — MaxExecutor tek başına yeterli |

---

## 7. YENİDEN DERLEME (kaynağı değiştirirsen)

```bash
# Debian/Ubuntu'da: sudo apt install g++-mingw-w64-i686 (root yoksa: apt-get download + dpkg -x)
# ONCELIKLI: PLUSMAXGOD_PyScript.py degistirdiysen gomulu kopyayi yeniden uret (FIX-22):
python3 scripts/embed_pylib.py        # pylib_embedded.h yenilenir (kaynak: PLUSMAXGOD_PyScript.py)
i686-w64-mingw32-g++ -shared -static -static-libgcc -static-libstdc++ -O2 \
    -o bin/MaxExecutor.dll MaxExecutor.cpp -luser32 -lkernel32 -lgdi32

i686-w64-mingw32-g++ -static -static-libgcc -O2 \
    -o bin/MaxInject.exe MaxInject.cpp -luser32 -lkernel32

# dogrulama (ikisi de pei-i386 / i386 cikmali):
i686-w64-mingw32-objdump -f bin/MaxExecutor.dll | grep architecture
# root-less alternatif (oturum 12-13 yolu):
#   zig c++ -target x86-windows-gnu -O2 -shared MaxExecutor.cpp -o bin/MaxExecutor.dll
#   zig c++ -target x86-windows-gnu -O2 MaxInject.cpp -o bin/MaxInject.exe
```
Visual Studio kullanacaksan: x86 platform, DLL projesi, `/MT` (statik CRT), ek include yok.

---

## 8. TEST KONTROL LİSTESİ (kullanıcı tarafında)

- [ ] `MaxInject.exe` → konsol açıldı, `python27.dll : BULUNDU`
- [ ] `PLUSMAXGOD_PyScript.py : v4.1 (uyumlu)` ya da `GUNCELLENDI -> v4.1` satırı göründü
- [ ] 30 sn sonra `results\last_pylib_load.txt` VAR (oto-yükleme kanıtı)
- [ ] `status` → `SCENE=LoginWindow+ServerList` benzeri çıktı
- [ ] `login id pwd` → `waitfor SelectCharacterWindow 30` ile ekran geçişi
- [ ] `charlist` → `results/last_charlist.txt` dolu (5 slot, race/level/isim)
- [ ] `enter 0` → `waitfor GameWindow 60` → **NPC'ler görünüyor mu?**
- [ ] **v1.8 oyun-ici:** `stat` + `pos` + `inv 0` + `equip` + `skill` raporları dolu mu?
- [ ] **v1.8 hareket:** `goto <x> <y>` yürüdü mü? (tp'yi önce güvenli yerde dene)
- [ ] **v1.8 kesif:** `pyfiles` → `pydumpall` → `C:\MaxExec\dump\INDEX.txt` oluştu mu?
- [ ] **v1.8 katalog:** `plusquest` → `dump\PLUSQuest_live.txt` oluştu mu? (AI'ya gönderilecek)
- [ ] (yeni karakter) `empire` + `create` + hata takibi
